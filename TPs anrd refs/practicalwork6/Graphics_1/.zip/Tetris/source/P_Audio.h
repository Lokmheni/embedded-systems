#pragma once

#include <nds.h>
#include <maxmod9.h>

void Audio_Init();
void Audio_PlaySoundEX( int i );
void Audio_PlaySound( int sound );
void Audio_PlayMusic();
