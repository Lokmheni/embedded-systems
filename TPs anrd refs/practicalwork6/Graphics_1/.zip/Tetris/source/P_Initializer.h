#include <nds.h>
#include "P_Map16x16.h"
#include "P_Audio.h"

void P_InitNDS();

