#include "P_Audio.h"

void Audio_Init()
{

}

void Audio_PlaySoundEX( int i )
{

}

void Audio_PlaySound( int sound )
{

}

void Audio_PlayMusic()
{

}
