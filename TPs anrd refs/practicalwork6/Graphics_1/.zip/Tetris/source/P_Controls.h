
#include <nds.h>


void handleInput();
